async function loadZoroSource(source) {
    let url = await fetch("https://api.fl-anime.com/anime/zoro/info?id=hk-hk-" + source) 
    let zoroData = await url.json()
    let zoroEp = zoroData.episodes[Number(ep) - 1]
    let zoroEpId = zoroEp.id
    let url2 = await fetch("https://api.fl-anime.com/anime/zoro/watch?episodeId=" + zoroEpId)
    zoroData2 = await url2.json()
    streamSource = zoroData2.sources.find(x => x.quality === 'auto')
    player.unload()
    player.load("https://cors.fl-anime.com/" + streamSource.url)
    video.addEventListener('loadeddata', (e) => {
        if (navigator.userAgent.includes("iPhone")) {
            loadSubsZoro();
        } else {
            if (video.readyState >= 3) {
                loadSubsZoro();
            }
        }
     });
}
async function loadSubsZoro() {
    let subtitles = zoroData2.subtitles;
    let subtitleForm;
    subtitles.forEach((track) => {
    if (track.lang == "English") {
        subtitleForm = "en"
    } else if (track.lang == "Arabic - العربية (Arabic)") {
        subtitleForm = "ar"
    } else if (track.lang == "French") {
        subtitleForm = "fr"
    } else if (track.lang == "Portuguese - Português (Brasil)") {
        subtitleForm = "pt"
    } else if (track.lang == "Spanish - Español (España)") {
        subtitleForm = "es"
    } else if (track.lang == "Russian - Русский (Russian)") {
        subtitleForm = "ru"
    } else if (track.lang == "German - Deutsch") {
        subtitleForm = "de"
    } else if (track.lang == "Italian - Italiano (Italian)") {
        subtitleForm = "it"
    }
    
    player.addTextTrackAsync(track.url, subtitleForm, 'subtitle', 'text/vtt', '', track.lang)
    }); 
}
async function defaultSourceLoad() {
    if (defaultSource == "gogoanime") {
        let showID = document.getElementById('gogoanime').value
        let url = await fetch("https://api.fl-anime.com/anime/gogoanime/watch/" + showID + '-episode-' + ep + "?server=vidstreaming")
        data = await url.json()
        streamSource = data.sources.find(x => x.quality === 'default')
        player.load("https://cors.fl-anime.com/?url=" + encodeURIComponent(streamSource.url));
    } else if (defaultSource == "zoro") {
        loadZoroSource(document.getElementById('zoro').value)
    } else {
        let showID = document.getElementById('gogoanime').value
        let url = await fetch("https://api.fl-anime.com/anime/gogoanime/watch/" + showID + '-episode-' + ep + "?server=vidstreaming")
        data = await url.json()
        streamSource = data.sources.find(x => x.quality === 'default')
        player.load("https://cors.fl-anime.com/?url=" + encodeURIComponent(streamSource.url));
    }
}
let zoroData2;
defaultSourceLoad()
document.getElementById('select-source').addEventListener('change', async function(e) {
    destroyAniSkipButton()
    let source = e.target.value;
    let selector = document.getElementById('select-source')
    let options = selector.options
    let selectedIndex = options[selector.selectedIndex].id.toLowerCase()

    if (selectedIndex == "gogoanime") {
        let url = await fetch("https://api.fl-anime.com/anime/" + selectedIndex + "/watch/" + source + '-episode-' + ep + "?server=vidstreaming")
        data = await url.json()
        streamSource = data.sources.find(x => x.quality === 'default')
        player.unload()
        player.load("https://cors.fl-anime.com/?url=" + encodeURIComponent(streamSource.url));
        destroyAniSkipButton()
    }
    if (selectedIndex == "gogoanime (dub)") {
        let url = await fetch("https://api.fl-anime.com/anime/gogoanime/watch/" + source + '-episode-' + ep + "?server=vidstreaming")
        data = await url.json()
        streamSource = data.sources.find(x => x.quality === 'default')
        player.unload()
        player.load("https://cors.fl-anime.com/?url=" + encodeURIComponent(streamSource.url));
        destroyAniSkipButton()
    }
    if (selectedIndex == "zoro") {
        loadZoroSource(source)
        destroyAniSkipButton()

    }
    if (selectedIndex == "animepahe") {
        let url = await fetch("https://api.fl-anime.com/anime/" + selectedIndex + "/info/" + source)
        let data = await url.json()
        let paheEp = data.episodes[Number(ep) - 1]
        let paheEpId = paheEp.id
        let url2 = await fetch("https://api.fl-anime.com/anime/" + selectedIndex + "/watch/" + paheEpId)
        data2 = await url2.json()
        console.log(data2)
        // this is what happens to a mf when there isn't an auto quality selector.
        streamSource = data2.sources.find(x => x.quality === '1080')
        if (streamSource == undefined) {
            streamSource = data2.sources.find(x => x.quality === '720')
        } if (streamSource == undefined) {
            streamSource = data2.sources.find(x => x.quality === '480')
        } if (streamSource == undefined) {
            streamSource = data2.sources.find(x => x.quality === '360')
        }
        player.unload() 
        player.load("https://hls.haikei.xyz/" + streamSource.url)
    }
})