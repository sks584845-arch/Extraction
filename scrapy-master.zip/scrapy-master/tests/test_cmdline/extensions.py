class DummyExtension:
    pass
