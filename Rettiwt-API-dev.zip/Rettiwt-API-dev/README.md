# Rettiwt-API

A CLI tool and an API for fetching data from Twitter for free!

## Prerequisites

- NodeJS 22
- A working Twitter account (optional)

## Installation

It is recommended to install the package globally, if you want to use it from the CLI. Use the following steps to install the package and ensure it's installed correctly:

1. Open a terminal.
2. Install the package using the command `npm install -g rettiwt-api`.
3. Check if the package is installed correctly using the command `rettiwt help`.

For using the package in your own project, you can install it as a [dependency](https://rishikant181.github.io/Rettiwt-API/#md:usage-as-a-dependency).

## Authentication

Rettiwt-API can be used with or without logging in to Twitter. As such, the two authentication strategies are:

- 'Guest' authentication (without logging in) grants access to the following resources/actions:

    - Tweet Details
    - Space Details
    - User Details (by username)
    - User Timeline

- 'User' authentication (logging in) grants access to the following resources/actions:

    - Direct Message Inbox
    - Direct Message Conversations
    - Direct Message Delete Conversation
    - Job Details
    - Job Locations
    - Job Search
    - List Add Member
    - List Details
    - List Members
    - List Mute
    - List Remove Member
    - List Tweets
    - List Unmute
    - List Update
    - Space Details
    - Tweet Details - Single and Bulk
    - Tweet History
    - Tweet Bookmark
    - Tweet Like
    - Tweet Likers
    - Tweet Media Upload
    - Tweet Post
    - Tweet Replies
    - Tweet Retweet
    - Tweet Retweeters
    - Tweet Schedule
    - Tweet Search
    - Tweet Stream
    - Tweet Unbookmark
    - Tweet Unlike
    - Tweet Unpost
    - Tweet Unretweet
    - Tweet Unschedule
    - User Affiliates
    - User Analytics (Only for Premium accounts)
    - User About Profile (by username)
    - User Bookmarks
    - User Bookmark Folders
    - User Bookmark Folder Tweets
    - User Details - Single (by ID and Username) and Bulk (by ID only)
    - User Follow
    - User Followed Feed
    - User Followers
    - User Following
    - User Highlights
    - User Likes
    - User Lists
    - User Media
    - User Notification
    - User Recommended Feed
    - User Remove Follower
    - User Replies Timeline
    - User Search
    - User Suggestions
    - User Subscriptions
    - User Timeline
    - User Unfollow
    - User Profile Update
    - User Profile Image Update
    - User Profile Banner Update
    - User Username Change
    - User Password Change

By default, Rettiwt-API uses 'guest' authentication. If however, access to the full set of resources is required, 'user' authentication can be used. This is done by using the cookies associated with your Twitter/X account, and encoding them into an `API_KEY` for convenience. The said `API_KEY` can be obtained by using a **Firefox** extension or manually from your browser (Chrome/Chromium-Based/Firefox/Firefox-Based), as follows:

### Manual Method

1. Open your browser (Chrome/Chromium-Based/Firefox/Firefox-Based) and go to Twitter/X.
2. Open your browser developer tools by pressing `F12` on your keyboard.
3. Navigate to Applications -> Cookies (for Chrome/Chromium-Based) or Storage -> Cookies (for Firefox/Firefox-Based).
4. Copy the values of the 3 fields: `auth_token`, `ct0`, `twid`. These server as your authentication credentials.
5. Go to `Console` of your browser developer tools, and execute the command: `btoa("auth_token=<auth_token_value>;ct0=<ct0_value>;twid=<twid_value>;")`. Substitute the values of the tokens with the values you copied.
6. The output string is your API_KEY.

### Firefox Extension Method

1. Install the [Rettiwt Auth Helper extension](https://addons.mozilla.org/en-US/firefox/addon/rettiwt-auth-helper) from Firefox Add-Ons, and allow it to run it in in-private mode.
2. Switch to in-private mode and login to Twitter/X.
3. After successful login, while still being on Twitter/X, click on the extension which will open the extension popup.
4. Click on the `Get API Key` button, this will generate the `API_KEY` and will show up in the text-area.
5. Copy the `API_KEY` by either clicking on the `Copy API Key` button or manually from the text-area.
6. You may close the browser, but don't log out. Remember, since it's in-private mode, you didn't explicity 'log out', so, while the session will be erased from the browser, the `API_KEY` still remains valid.
7. Save the `API_KEY` for use.

#### Notes:

- `API_KEY` created in this way should last 5 years from the date of login, as long as the credentials to the account aren't changed.
- This approach can also be done without going into incognito/in-private mode, in which case you can either login as usual or skip the login step if you're already logged in, and continue from the steps after login. However, this makes the `API_KEY` to last only as long as the Twitter/X account isn't logged out of (you may exit the browser as usual) or 5 years, whichever comes first. That's why it's recommended to use incognito/in-private mode, so that the `API_KEY` isn't accidentially revoked by logging out.

## The API_KEY

The API_KEY generated by logging in is what allows Rettiwt-API to authenticate as a logged in user while interacting with the Twitter API ('user' authentication). As such it is a very sensitive information and therefore, must be stored securely. The following points must be kept in mind while using the API_KEY for 'user' authentication:

- The API_KEY is actually a base64 encoding of the account's cookies.
- The API_KEY provides the same level of authorization as any standard Twitter account, nothing more, nothing less.

## Notes for non-programmers

- If you have no idea of programming, it's recommended to use the CLI.
- The CLI provides an easy to use interface which does not require any knowledge of JavaScript or programming
- Please skip to [CLI-Usage](https://rishikant181.github.io/Rettiwt-API/#md:cli-usage) for details.

## Usage as a dependency

Rettiwt-API can be used as a dependency for your NodeJS project. In such a case, it is not required to install Rettiwt-API globally and you may install it locally in the root of your project using the command:

- `npm install --save rettiwt-api` (using npm)

    or

- `yarn add rettiwt-api` (using yarn)

However, in this case, for accessing the CLI, you will be required to prepend the CLI commands with `npx` in order to tell NodeJS to use the locally installed package.

## The Rettiwt class

When used as a dependency, the [Rettiwt](https://rishikant181.github.io/Rettiwt-API/classes/Rettiwt.html) class is entry point for accessing the Twitter API.

A new Rettiwt instance can be initialized using the following code snippets:

- `const rettiwt = new Rettiwt()` (for 'guest' authentication)
- `const rettiwt = new Rettiwt({ apiKey: API_KEY })` (for 'user' authentication)

The Rettiwt class has five members:

- `dm` member, for accessing resources related to direct messages.
- `list` member, for accessing resources related to lists.
- `space` member, for accessing resources related to spaces.
- `tweet` member, for accessing resources related to tweets.
- `user` member, for accessing resources related to users.

For details regarding usage of these members for accessing the Twitter API, refer to [features](https://rishikant181.github.io/Rettiwt-API/#md:features).

## Rettiwt Configuration

When initializing a new Rettiwt instance, it can be configures using various parameters, namely:

- `apiKey` (string) - The API key to use for `user` authentication.
- `proxy` (string | AxiosProxyConfig) - The proxy server to use.
- `timeout` (number) - The timeout to use for HTTP requests used by Rettiwt.
- `logging` (boolean) - Whether to enable logging or not.
- `errorHandler` (interface) - The custom error handler to use.
- `headers` (object) - Custom HTTP headers to append to the default headers.
- `delay` (number/function) - The delay to use between concurrent requests, can either be a number in milliseconds, or a function that returns the number. Default is 0 (no delay).
- `maxRetries` (number) - The maximum number of retries to use in case when a random error 404 is encountered. Default is 0 (no retries).

Of these parameters, the following are hot-swappable, using their respective setters:

- `apiKey`
- `headers`
- `proxy`

The following example demonstrates changing the API key on the fly:

```ts
import { Rettiwt } from 'rettiwt-api';

// Initializing a new Rettiwt instance with API key 1
const rettiwt = new Rettiwt({ apiKey: '<API_KEY_1>' });

rettiwt.user.details().then((res) => {
	console.log(res); // Returns details of the user associated with API_KEY_1
});

// Changing API key to API key 2
rettiwt.apiKey = '<API_KEY_2>';

rettiwt.user.details().then((res) => {
	console.log(res); // Returns details of the user associated with API_KEY_2
});
```

## Usage

The following examples may help you to get started using the library:

### 1. Getting the details of a target Twitter user

```ts
import { Rettiwt } from 'rettiwt-api';

// Creating a new Rettiwt instance
// Note that for accessing user details, 'guest' authentication can be used
const rettiwt = new Rettiwt();

// Fetching the details of the user whose username is <username>
rettiwt.user.details('<username>')
.then(details => {
	...
})
.catch(error => {
	...
});
```

### 2. Getting the list of tweets that match a given filter

```ts
import { Rettiwt } from 'rettiwt-api';

// Creating a new Rettiwt instance using the API_KEY
const rettiwt = new Rettiwt({ apiKey: API_KEY });

/**
 * Fetching the list of tweets that:
 * 	- are made by a user with username <username>,
 * 	- contain the words <word1> and <word2>
 */
rettiwt.tweet.search({
	fromUsers: ['<username>'],
	includeWords: ['<word1>', '<word2>']
})
.then(data => {
	...
})
.catch(err => {
	...
});
```

For more information regarding the different available filter options, please refer to [TweetFilter](https://rishikant181.github.io/Rettiwt-API/classes/TweetFilter.html).

### 3. Getting the next batch of data using a cursor

The previous example fetches the the list of tweets matching the given filter. Since no count is specified, in this case, a default of 20 such Tweets are fetched initially. The following example demonstrates how to use the [cursor string](https://rishikant181.github.io/Rettiwt-API/classes/Cursor.html#value) obtained from the [response](https://rishikant181.github.io/Rettiwt-API/classes/CursoredData.html) object's [next](https://rishikant181.github.io/Rettiwt-API/classes/CursoredData.html#next) field, from the previous example, to fetch the next batch of tweets:

```ts
import { Rettiwt } from 'rettiwt-api';

// Creating a new Rettiwt instance using the API_KEY
const rettiwt = new Rettiwt({ apiKey: API_KEY });

/**
 * Fetching the list of tweets that:
 * 	- are made by a user with username <username>,
 * 	- contain the words <word1> and <word2>
 *
 * 'data' is the response object received in the previous example.
 *
 * 'count' is a number less or equal to 20 (the quantity of tweets to return)
 */
rettiwt.tweet.search({
	fromUsers: ['<username>'],
	includeWords: ['<word1>', '<word2>']
}, count, data.next.value)
.then(data => {
	...
})
.catch(err => {
	...
});
```

### 4. Searching X Jobs

```ts
import { Rettiwt } from 'rettiwt-api';

// Creating a new Rettiwt instance using the API_KEY
const rettiwt = new Rettiwt({ apiKey: API_KEY });

// Fetching the first 25 jobs matching Discord
rettiwt.job.search('Discord', 25)
.then(data => {
	...
})
.catch(err => {
	...
});
```

The details of a specific job can be fetched using its job ID:

```ts
rettiwt.job.details('<job_id>')
.then(data => {
	...
})
.catch(err => {
	...
});
```

Suggested locations for the jobs location selector can be fetched as follows:

```ts
rettiwt.job.locations('Grenoble')
.then(data => {
	...
})
.catch(err => {
	...
});
```

### 5. Getting the edit history of a tweet

```ts
import { Rettiwt } from 'rettiwt-api';

// Creating a new Rettiwt instance using the API_KEY
const rettiwt = new Rettiwt({ apiKey: API_KEY });

// Fetching the edit history of the tweet whose ID is <tweet_id>
rettiwt.tweet.history('<tweet_id>')
.then(tweets => {
	...
})
.catch(err => {
	...
});
```

## Using a response middleware

`Rettiwt` allows configuring a response middleware, which provides access to the raw `AxiosResponse` object, as received from Twitter. The middleware is non-blocking in nature, and serves purely as an accessorial method.

This is especially helpful getting access to response headers like rate limit information.

The following example demonstrates using a custom response handler for getting rate limit information:

```ts
// Creating a new Rettiwt instance using guest auth
const rettiwt = new Rettiwt({
	responseMiddleware: (res): void => {
		console.log(`Rate limit: ${res.headers['x-rate-limit-limit']}`);
		console.log(`Rate limit remaining: ${res.headers['x-rate-limit-remaining']}`);
		console.log(`Rate limit reset timestamp (seconds): ${res.headers['x-rate-limit-reset']}`);
		console.log('\n');
	},
});

// Getting the details of user by username
rettiwt.user
	.details('negmatico')
	.then((res) => {
		console.log(res.toJSON());

		// Results in similar data being logged to console, as follows:

		// Rate limit: 50
		// Rate limit reamining: 49
		// Rate limit reset timestamp (seconds): 1775416043
		//
		// {
		//     "createdAt": "2021-07-24T14:25:32.000Z",
		//     "description": "Coder, Gamer and Tech Enthusiast",
		//     "followersCount": 3,
		//     "followingsCount": 44,
		//     "fullName": "Rishikant Sahu",
		//     "id": "1418940387037782018",
		//     "isVerified": false,
		//     "likeCount": 762,
		//     "profileImage": "https://abs.twimg.com/sticky/default_profile_images/default_profile_normal.png",
		//     "statusesCount": 5,
		//     "userName": "negmatico"
		// }
	})
	.catch((err) => {
		console.log(err);
	});
```

## Using a custom error handler

Out of the box, `Rettiwt`'s error handling is bare-minimum, only able to parse basic error messages. For advanced scenarios, where full error response might be required, in order to diagnose error reason, it's recommended to use a custom error handler, by implementing the `IErrorHandler` interface, as follows:

```ts
import { Rettiwt, IErrorHandler } from 'rettiwt-api';

// Implementing an error handler
class CustomErrorHandler implements IErrorHandler {
	/**
	 * This is where you handle the error yourself.
	 */
	public handler(error: unknown): void {
		// The 'error' variable has the full, raw error response returned from Twitter.
		/**
		 * You custom error handling logic goes here
		 */

		console.log(`Raw Twitter Error: ${JSON.stringify(error)}`);
	}
}

// Now we'll use the implemented error handler while initializing Rettiwt
const rettiwt = new Rettiwt({ apiKey: '<API_KEY>', errorHandler: CustomErrorHandler });
```

You can then use the created `rettiwt` instance and your custom error handler will handler all the error responses, bypassing `Rettiwt`'s error handling logic.

## Using a proxy

For masking of IP address using a proxy server (HTTP/HTTPS/SOCKS), use the following code snippet for instantiation of Rettiwt:

- Using an HTTP/HTTPS proxy:

    ```ts
    /**
     * <PROXY_URL_STRING_OR_CONFIG> is the URL string or `AxiosProxyConfiguration` for the HTTP/HTTPS proxy server you want to use.`
     */
    const rettiwt = new Rettiwt({ apiKey: API_KEY, proxy: '<PROXY_URL_STRING_OR_CONFIG>' });
    ```

- Using an SOCKS proxy:

    ```ts
    /**
     * <PROXY_URL> is the URL string to the SOCKS proxy server you want to use.`
     */
    const rettiwt = new Rettiwt({ apiKey: API_KEY, proxy: '<PROXY_URL>' });
    ```

This creates a Rettiwt instance which uses the given proxy server for making requests to Twitter.

## Debug logs

Sometimes, when the library shows unexpected behaviour, for troubleshooting purposes, debug logs can be enabled which will help in tracking down the issue and working on a potential fix. Currently, debug logs are printed to the console and are enabled by setting the 'logging' property of the config to true, while creating an instance of Rettiwt:

```ts
/**
 * By default, is no value for 'logging' is supplied, logging is disabled.
 */
const rettiwt = new Rettiwt({ apiKey: API_KEY, logging: true });
```

## Accessing raw response

For getting the raw data instead of the parsed results, all data models provide a getter `raw` which returns the raw data entity as returned by Twitter, instead of parsing them to Rettiwt's own data entity formats. The following example demonstrates the use of the `raw` getter:

```ts
import { Rettiwt } from 'rettiwt-api';

// Creating a new Rettiwt instance
// Note that for accessing user details, 'guest' authentication can be used
const rettiwt = new Rettiwt();

// Fetching the details of the user whose username is <username>
rettiwt.user.details('<username>')
.then(details => {
	console.log(details);
    // {
    //     "createdAt": "2021-07-24T14:25:32.000Z",
    //     "description": "Coder, Gamer and Tech Enthusiast",
    //     "followersCount": 3,
    //     "followingsCount": 44,
    //     "fullName": "Rishikant Sahu",
    //     "id": "1418940387037782018",
    //     "isVerified": false,
    //     "likeCount": 762,
    //     "profileImage": "https://abs.twimg.com/sticky/default_profile_images/default_profile_normal.png",
    //     "statusesCount": 5,
    //     "userName": "negmatico"
    // }

    console.log(details.raw);
    // {
    //     "__typename": "User",
    //     "id": "VXNlcjoxNDE4OTQwMzg3MDM3NzgyMDE4",
    //     "rest_id": "1418940387037782018",
    //     "affiliates_highlighted_label": {},
    //     "has_graduated_access": true,
    //     "is_blue_verified": false,
    //     "legacy": {
    //         "following": false,
    //         "can_dm": true,
    //         "can_media_tag": true,
    //         "created_at": "Sat Jul 24 14:25:32 +0000 2021",
    //         "default_profile": true,
    //         "default_profile_image": true,
    //         "description": "Coder, Gamer and Tech Enthusiast",
    //         "entities": { "description": { "urls": [] } },
    //         "fast_followers_count": 0,
    //         "favourites_count": 762,
    //         "followers_count": 3,
    //         "friends_count": 44,
    //         "has_custom_timelines": false,
    //         "is_translator": false,
    //         "listed_count": 0,
    //         "location": "",
    //         "media_count": 0,
    //         "name": "Rishikant Sahu",
    //         "needs_phone_verification": false,
    //         "normal_followers_count": 3,
    //         "pinned_tweet_ids_str": [],
    //         "possibly_sensitive": false,
    //         "profile_image_url_https": "https://abs.twimg.com/sticky/default_profile_images/default_profile_normal.png",
    //         "profile_interstitial_type": "",
    //         "screen_name": "negmatico",
    //         "statuses_count": 5,
    //         "translator_type": "none",
    //         "verified": false,
    //         "want_retweets": false,
    //         "withheld_in_countries": []
    //     },
    //     "parody_commentary_fan_label": "None",
    //     "profile_image_shape": "Circle",
    //     "tipjar_settings": {},
    //     "verified_phone_status": false,
    //     "legacy_extended_profile": {
    //         "birthdate": { "day": 18, "month": 1, "year": 2001, "visibility": "Self", "year_visibility": "Self" }
    //     },
    //     "is_profile_translatable": false,
    //     "has_hidden_subscriptions_on_profile": false,
    //     "verification_info": { "is_identity_verified": false },
    //     "highlights_info": { "can_highlight_tweets": false, "highlighted_tweets": "0" },
    //     "user_seed_tweet_count": 0,
    //     "premium_gifting_eligible": true,
    //     "business_account": {},
    //     "creator_subscriptions_count": 0
    // }

})
.catch(error => {
	...
});
```

However, if further control over the raw response is required, Rettiwt-API provides the [`FetcherService`](https://rishikant181.github.io/Rettiwt-API/classes/FetcherService.html) class which provides direct access to the raw response, but keep in mind, this delegates the task of parsing and filtering the results to the consumer of the library. The following example demonstrates using the `FetcherService` class:

```ts
import { RettiwtConfig, FetcherService, ResourceType, IUserDetailsResponse } from 'rettiwt-api';

// Creating the configuration for Rettiwt
const config = new RettiwtConfig({ apiKey: '<API_KEY>' });

// Creating a new FetcherService instance using the config
const fetcher = new FetcherService(config);

// Fetching the details of the given user
fetcher
	.request<IUserDetailsResponse>(ResourceType.USER_DETAILS_BY_USERNAME, { id: 'user1' })
	.then((res) => {
		console.log(res);
	})
	.catch((err) => {
		console.log(err);
	});
```

As demonstrated by the example, the raw data can be accessed by using the `request` method of the `FetcherService` class, which takes two parameters. The first parameter is the name of the requested resource, while the second is an object specifying the associated arguments required for the given resource. The complete list of resource type can be checked [here](https://rishikant181.github.io/Rettiwt-API/enums/AuthService.html#ResourceType). As for the resource specific argurments, they are the same as that of the methods of `Rettiwt` class' methods for the respective resources, but structured as an object. Notice how the `FetcherService` class takes the same arguments as the `Rettiwt` class, and the arguments have the same effects as they have in case of `Rettiwt` class.

#### Notes:

- For for hot-swapping in case of using `FetcherService`, the setters are accessed from the `config` object as `config.apiKey = ...`, `config.proxyUrl = ...`, etc.

## Data serialization

The data returned by all functions of `Rettiwt` are complex objects, containing non-serialized fields like `raw`. In order to get JSON-serializable data, all data objects returned by `Rettiwt` provide a function `toJSON()` which converts the data into a serializable JSON, whose type is described by their respective interfaces i.e, `ITweet` for `Tweet`, `IUser` for `User` and so on.

For handling and processing of data returned by the functions, it's always advisable to serialize them using the `toJSON()` function.

## Features

So far, the following operations are supported:

### Direct Messages

- [Getting the DM inbox](https://rishikant181.github.io/Rettiwt-API/classes/DirectMessageService.html#inbox)
- [Getting a specific conversation with full message history](https://rishikant181.github.io/Rettiwt-API/classes/DirectMessageService.html#conversation)
- [Deleting a conversation](https://rishikant181.github.io/Rettiwt-API/classes/DirectMessageService.html#deleteConversation)

### Jobs

- [Getting the details of an X Job](https://rishikant181.github.io/Rettiwt-API/classes/JobService.html#details)
- [Getting suggested X Job locations](https://rishikant181.github.io/Rettiwt-API/classes/JobService.html#locations)
- [Searching for X Jobs](https://rishikant181.github.io/Rettiwt-API/classes/JobService.html#search)

### List

- [Adding a member to a given Twitter list](https://rishikant181.github.io/Rettiwt-API/classes/ListService.html#addMember)
- [Getting the details of a given Twitter list](https://rishikant181.github.io/Rettiwt-API/classes/ListService.html#details)
- [Getting the members of a given Twitter list](https://rishikant181.github.io/Rettiwt-API/classes/ListService.html#members)
- [Muting a list](https://rishikant181.github.io/Rettiwt-API/classes/ListService.html#mute)
- [Removing a member from a given Twitter list](https://rishikant181.github.io/Rettiwt-API/classes/ListService.html#removeMember)
- [Getting the list of tweets from a given Twitter list](https://rishikant181.github.io/Rettiwt-API/classes/ListService.html#tweets)
- [Unmuting a list](https://rishikant181.github.io/Rettiwt-API/classes/ListService.html#unmute)
- [Updating a list](https://rishikant181.github.io/Rettiwt-API/classes/ListService.html#update)

### Space

- [Getting the details of a space](https://rishikant181.github.io/Rettiwt-API/classes/SpaceService.html#details)

### Tweets

- [Bookmarking a tweet](https://rishikant181.github.io/Rettiwt-API/classes/TweetService.html#bookmark)
- [Getting the details of a tweet/multiple tweets](https://rishikant181.github.io/Rettiwt-API/classes/TweetService.html#details)
- [Getting the edit history of a tweet](https://rishikant181.github.io/Rettiwt-API/classes/TweetService.html#history)
- [Liking a tweet](https://rishikant181.github.io/Rettiwt-API/classes/TweetService.html#like)
- [Getting the list of users who liked your tweet](https://rishikant181.github.io/Rettiwt-API/classes/TweetService.html#likers)
- [Posting a new tweet](https://rishikant181.github.io/Rettiwt-API/classes/TweetService.html#post)
- [Getting the list of replies to a tweet](https://rishikant181.github.io/Rettiwt-API/classes/TweetService.html#replies)
- [Retweeting a tweet](https://rishikant181.github.io/Rettiwt-API/classes/TweetService.html#retweet)
- [Getting the list of users who retweeted a given tweet by the logged-in user](https://rishikant181.github.io/Rettiwt-API/classes/TweetService.html#retweeters)
- [Scheduling a new tweet](https://rishikant181.github.io/Rettiwt-API/classes/TweetService.html#schedule)
- [Searching for the list of tweets that match a given filter](https://rishikant181.github.io/Rettiwt-API/classes/TweetService.html#search)
- [Streaming filtered tweets in pseudo-realtime](https://rishikant181.github.io/Rettiwt-API/classes/TweetService.html#stream)
- [Unbookmarking a tweet](https://rishikant181.github.io/Rettiwt-API/classes/TweetService.html#unbookmark)
- [Unliking a tweet](https://rishikant181.github.io/Rettiwt-API/classes/TweetService.html#unlike)
- [Unposting a tweet](https://rishikant181.github.io/Rettiwt-API/classes/TweetService.html#unpost)
- [Unretweeting a tweet](https://rishikant181.github.io/Rettiwt-API/classes/TweetService.html#unretweet)
- [Unscheduling a tweet](https://rishikant181.github.io/Rettiwt-API/classes/TweetService.html#unschedule)
- [Uploading a media file for a tweet](https://rishikant181.github.io/Rettiwt-API/classes/TweetService.html#upload)

### Users

- [Getting the list of users affiliated with the given user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#affiliates)
- [Getting the analytics of the logged-in user (premium accounts only)](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#analytics)
- [Getting the about profile of a user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#about)
- [Getting the list of tweets bookmarked by the logged-in user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#bookmarks)
- [Getting the list of bookmark folders of the logged-in user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#bookmarkFolders)
- [Getting the list of tweets in a specific bookmark folder](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#bookmarkFolderTweets)
- [Getting the details of a user/multiple users](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#details)
- [Following a given user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#follow)
- [Removing a follower](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#removeFollower)
- [Getting the followed feed of the logged-in user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#followed)
- [Getting the list of users who follow the given user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#followers)
- [Getting the list of users who are followed by the given user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#following)
- [Getting the list of highlighted tweets of the given user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#highlights)
- [Getting the list of tweets liked by the logged-in user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#likes)
- [Getting the lists of the logged-in user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#lists)
- [Getting the media timeline of the given user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#media)
- [Streaming notifications of the logged-in user in pseudo-realtime](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#notifications)
- [Getting the recommended feed of the logged-in user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#recommended)
- [Getting the replies timeline of the given user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#replies)
- [Searching for a username](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#search)
- [Getting suggested users from the Connect tab](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#suggestions)
- [Getting the tweet timeline of the given user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#timeline)
- [Unfollowing a given user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#unfollow)
- [Updating the profile of the logged-in user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#updateProfile)
- [Updating the profile image of the logged-in user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#updateProfileImage)
- [Updating the profile banner of the logged-in user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#updateProfileBanner)
- [Changing the username of the logged-in user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#changeUsername)
- [Changing the password of the logged-in user](https://rishikant181.github.io/Rettiwt-API/classes/UserService.html#changePassword)

## CLI Usage

Rettiwt-API provides an easy to use command-line interface which does not require any programming knowledge.

By default, the CLI operates in 'guest' authentication. If you want to use 'user' authentication:

1. Generate an API_KEY as described in [Authentication](https://rishikant181.github.io/Rettiwt-API/#md:authentication).
2. Store the output API_KEY as an environment variable with the name 'API_KEY'.
    - Additionally, store the API_KEY in a file for later use.
    - Make sure to generate an API_KEY only once, and use it every time you need it.
3. The CLI automatically reads this environment variable to authenticate against Twitter.
    - Additionally, the API_KEY can also be passed in manually using the '-k' option as follows: `rettiwt -k <API_KEY> <command>`

Help for the CLI can be obtained from the CLI itself:

- For help regarding the available commands, use the command `rettiwt help`
- For help regarding a specific command, use the command `rettiwt help <command_name>`
- For fetching the details of an X Job, use the command `rettiwt job details <job_id>`
- For fetching suggested X Job locations, use the command `rettiwt job locations <query>`
- For searching X Jobs, use the command `rettiwt job search <keyword>`
- For fetching the edit history of a tweet, use the command `rettiwt tweet history <tweet_id>`
- For fetching suggested users from the Connect tab, use the command `rettiwt user suggestions`

## API Reference

The complete API reference can be found at [this](https://rishikant181.github.io/Rettiwt-API/modules) page.

## Additional information

- This API uses the cookies of a Twitter account to fetch data from Twitter and as such, there is always a chance (although a measly one) of getting the account banned by Twitter algorithm.

## Donation

Support this project by donating at my [PayPal](https://paypal.me/Rishikant181?country.x=IN&locale.x=en_GB).
