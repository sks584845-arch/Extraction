import { JobEmploymentType, JobLocationType, JobSeniorityLevel } from '../../enums/Job';
import { RawAnalyticsGranularity, RawAnalyticsMetric } from '../../enums/raw/Analytics';
import { TweetRepliesSortType } from '../../enums/Tweet';

/**
 * Options specifying the data that is to be fetched.
 *
 * @public
 */
export interface IFetchArgs {
	/**
	 * The id of the active conversation.
	 *
	 * @remarks
	 * - Required only for {@link ResourceType.DM_USER_UPDATES}.
	 */
	activeConversationId?: string;

	/**
	 * The maximum id of the data to fetch.
	 *
	 * @remarks
	 * - May be used for {@link ResourceType.DM_INBOX_TIMELINE} and {@link ResourceType.DM_CONVERSATION}.
	 */
	maxId?: string;

	/**
	 * The id of the conversation to fetch.
	 *
	 * @remarks
	 * - Required only for {@link ResourceType.DM_CONVERSATION} and {@link ResourceType.DM_DELETE_CONVERSATION}.
	 */
	conversationId?: string;

	/**
	 * The number of data items to fetch.
	 *
	 * @remarks
	 * - Works only for cursored resources.
	 * - Does not work for {@link ResourceType.TWEET_REPLIES}.
	 * - Must be \<= 20 for:
	 * 	- {@link ResourceType.USER_TIMELINE}
	 * 	- {@link ResourceType.USER_TIMELINE}
	 * 	- {@link ResourceType.USER_TIMELINE_AND_REPLIES}
	 * - Must be \<= 100 for all other cursored resources.
	 * - Due a bug on Twitter's end, count does not work for {@link ResourceType.USER_FOLLOWERS} and {@link ResourceType.USER_FOLLOWING}.
	 * - Has not effect for:
	 * 	- {@link ResourceType.USER_FEED_FOLLOWED}
	 * 	- {@link ResourceType.USER_FEED_RECOMMENDED}
	 * 	- {@link ResourceType.USER_SUGGESTIONS}
	 */
	count?: number;

	/**
	 * The cursor to the batch of data to fetch.
	 *
	 * @remarks
	 * - May be used for cursored resources.
	 * - Has no effect for other resources.
	 */
	cursor?: string;

	/**
	 * Whether to fetch creator-only suggested users.
	 *
	 * @remarks
	 * - Only works for {@link ResourceType.USER_SUGGESTIONS}.
	 */
	creatorOnly?: boolean;

	/**
	 * The filter for searching tweets.
	 *
	 * @remarks
	 * Required when searching for tweets using {@link ResourceType.TWEET_SEARCH}.
	 */
	filter?: ITweetFilter;

	/**
	 * The filter for searching X Jobs.
	 *
	 * @remarks
	 * Required when searching for X Jobs using {@link ResourceType.JOB_SEARCH}.
	 */
	jobFilter?: IJobSearchFilter;

	/**
	 * The id of the target resource.
	 *
	 * @remarks
	 * - Required for all resources except {@link ResourceType.TWEET_SEARCH} and {@link ResourceType.USER_TIMELINE_RECOMMENDED}.
	 * - For {@link ResourceType.USER_DETAILS_BY_USERNAME}, {@link ResourceType.USER_ABOUT_BY_USERNAME}, and {@link ResourceType.USER_SEARCH}, can be alphanumeric, while for others, is strictly numeric.
	 */
	id?: string;

	/**
	 * The IDs of the target resources.
	 *
	 * @remarks
	 * - Required only for {@link ResourceType.TWEET_DETAILS_BULK} and {@link ResourceType.USER_DETAILS_BY_IDS_BULK}.
	 */
	ids?: string[];

	/**
	 * Whether to include replay information when fetching space details.
	 *
	 * @remarks
	 * - Only works for {@link ResourceType.SPACE_DETAILS}.
	 */
	withReplays?: boolean;

	/**
	 * Whether to include listeners information when fetching space details.
	 *
	 * @remarks
	 * - Only works for {@link ResourceType.SPACE_DETAILS}.
	 */
	withListeners?: boolean;

	/**
	 * Whether to request metatags for space details.
	 *
	 * @remarks
	 * - Only works for {@link ResourceType.SPACE_DETAILS}.
	 */
	isMetatagsQuery?: boolean;

	/**
	 * The sorting to use for tweet results.
	 *
	 * @remarks
	 * - Only works for {@link ResourceType.TWEET_REPLIES}.
	 */
	sortBy?: TweetRepliesSortType;

	/**
	 * The date to start fetching data from.
	 *
	 * @remarks
	 * - Only works for {@link EResourceType.USER_ANALYTICS}.
	 */
	fromTime?: Date;

	/**
	 * The date to end fetching data at.
	 *
	 * @remarks
	 * - Only works for {@link EResourceType.USER_ANALYTICS}.
	 */
	toTime?: Date;

	/**
	 * The granularity of the data to fetch.
	 *
	 * @remarks
	 * - Only works for {@link EResourceType.USER_ANALYTICS}.
	 */
	granularity?: RawAnalyticsGranularity;

	/**
	 * The metrics to fetch.
	 *
	 * @remarks
	 * - Only works for {@link EResourceType.USER_ANALYTICS}.
	 */
	metrics?: RawAnalyticsMetric[];

	/**
	 * Show the verified follower count and relationship counts in the response.
	 *
	 * @remarks
	 * - Only works for {@link EResourceType.USER_ANALYTICS}.
	 */
	showVerifiedFollowers?: boolean;
}

/**
 * Options specifying the data that is to be fetched for space details.
 *
 * @public
 */
export interface ISpaceDetailsOptions {
	/** Whether to include replay information. */
	withReplays?: boolean;

	/** Whether to include listeners information. */
	withListeners?: boolean;

	/** Whether the request is a metatags query. */
	isMetatagsQuery?: boolean;
}

/**
 * The filter to be used for searching tweets.
 *
 * @public
 */
export interface ITweetFilter {
	/** The date upto which tweets are to be searched. */
	endDate?: Date;

	/** The list of words to exclude from search. */
	excludeWords?: string[];

	/**
	 * The list of usernames whose tweets are to be searched.
	 *
	 * @remarks
	 * '\@' must be excluded from the username!
	 */
	fromUsers?: string[];

	/**
	 * The list of hashtags to search.
	 *
	 * @remarks
	 * '#' must be excluded from the hashtag!
	 */
	hashtags?: string[];

	/** The exact phrase to search. */
	includePhrase?: string;

	/** The list of words to search. */
	includeWords?: string[];

	/** The language of the tweets to search. */
	language?: string;

	/** The list from which tweets are to be searched. */
	list?: string;

	/** The id of the tweet, before which the tweets are to be searched. */
	maxId?: string;

	/**
	 * The list of username mentioned in the tweets to search.
	 *
	 * @remarks
	 * '\@' must be excluded from the username!
	 */
	mentions?: string[];

	/** The minimun number of likes to search by. */
	minLikes?: number;

	/** The minimum number of replies to search by. */
	minReplies?: number;

	/** The minimum number of retweets to search by. */
	minRetweets?: number;

	/**
	 * Whether to search only posts that contain links.
	 *
	 * @remarks 'links' includes things like media, quotes, retweets, etc.
	 */
	onlyLinks?: boolean;

	/** Whether to search only original posts. */
	onlyOriginal?: boolean;

	/** Whether to search only replies */
	onlyReplies?: boolean;

	/** Whether to search posts that only contain text. */
	onlyText?: boolean;

	/** The optional words to search. */
	optionalWords?: string[];

	/** The id of the tweet which is quoted in the tweets to search. */
	quoted?: string;

	/** The id of the tweet, after which the tweets are to be searched. */
	sinceId?: string;

	/** The date starting from which tweets are to be searched. */
	startDate?: Date;

	/**
	 * The list of username to whom the tweets to be searched, are adressed.
	 *
	 * @remarks
	 * '\@' must be excluded from the username!
	 */
	toUsers?: string[];

	/** Whether to fetch top tweets or not. */
	top?: boolean;
}

/**
 * The filter to be used for searching X Jobs.
 *
 * @public
 */
export interface IJobSearchFilter {
	/** The company whose jobs are to be searched. */
	companyName?: string;

	/** The employment types to search. */
	employmentTypes?: JobEmploymentType[];

	/** The industry to search. */
	industry?: string;

	/** The keyword to search. */
	keyword?: string;

	/** The location to search. */
	location?: string;

	/** The location id to search. */
	locationId?: string;

	/** The location ids to search. */
	locationIds?: string[];

	/** The location types to search. */
	locationTypes?: JobLocationType[];

	/** The seniority levels to search. */
	seniorityLevels?: JobSeniorityLevel[];
}
