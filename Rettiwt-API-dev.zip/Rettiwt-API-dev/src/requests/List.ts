import { AxiosRequestConfig } from 'axios';

import { IListUpdates, INewList } from '../types/args/PostArgs';

/**
 * Collection of requests related to lists.
 *
 * @public
 */
export class ListRequests {
	/**
	 * @param listId - The ID of the target list.
	 * @param userId - The ID of the user to be added as a member.
	 */
	public static addMember(listId: string, userId: string): AxiosRequestConfig {
		return {
			method: 'post',
			url: 'https://x.com/i/api/graphql/EadD8ivrhZhYQr2pDmCpjA/ListAddMember',
			data: {
				/* eslint-disable @typescript-eslint/naming-convention */

				variables: {
					listId: listId,
					userId: userId,
				},
				features: {
					profile_label_improvements_pcf_label_in_post_enabled: true,
					responsive_web_profile_redirect_enabled: false,
					rweb_tipjar_consumption_enabled: true,
					verified_phone_label_enabled: true,
					responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
					responsive_web_graphql_timeline_navigation_enabled: true,
				},

				/* eslint-enable @typescript-eslint/naming-convention */
			},
		};
	}

	/**
	 * @param list - The details of the list to create.
	 */
	public static create(list: INewList): AxiosRequestConfig {
		return {
			method: 'post',
			headers: { referer: 'https://x.com/i/lists/create' },
			url: 'https://x.com/i/api/graphql/4lSOF4GqldI-NbiFET4ofQ/CreateList',
			data: {
				/* eslint-disable @typescript-eslint/naming-convention */

				variables: {
					isPrivate: list.isPrivate ?? false,
					name: list.name,
					...(list.description !== undefined ? { description: list.description } : {}),
				},
				features: {
					profile_label_improvements_pcf_label_in_post_enabled: true,
					responsive_web_profile_redirect_enabled: false,
					rweb_tipjar_consumption_enabled: false,
					verified_phone_label_enabled: false,
					responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
					responsive_web_graphql_timeline_navigation_enabled: true,
				},
				queryId: '4lSOF4GqldI-NbiFET4ofQ',

				/* eslint-enable @typescript-eslint/naming-convention */
			},
		};
	}

	/**
	 * @param id - The ID of the list to delete.
	 */
	public static delete(id: string): AxiosRequestConfig {
		return {
			method: 'post',
			headers: { referer: `https://x.com/i/lists/${id}/info` },
			url: 'https://x.com/i/api/graphql/UnN9Th1BDbeLjpgjGSpL3Q/DeleteList',
			data: {
				variables: {
					listId: id,
				},
				queryId: 'UnN9Th1BDbeLjpgjGSpL3Q',
			},
		};
	}

	/**
	 * @param id - The id of the list whose details are to be fetched.
	 */
	public static details(id: string): AxiosRequestConfig {
		return {
			method: 'get',
			url: 'https://x.com/i/api/graphql/Tzkkg-NaBi_y1aAUUb6_eQ/ListByRestId',
			params: {
				/* eslint-disable @typescript-eslint/naming-convention */
				variables: JSON.stringify({ listId: id }),
				features: JSON.stringify({
					profile_label_improvements_pcf_label_in_post_enabled: true,
					responsive_web_profile_redirect_enabled: false,
					rweb_tipjar_consumption_enabled: true,
					verified_phone_label_enabled: true,
					responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
					responsive_web_graphql_timeline_navigation_enabled: true,
				}),
				/* eslint-enable @typescript-eslint/naming-convention */
			},
			paramsSerializer: { encode: encodeURIComponent },
		};
	}

	/**
	 * @param id - The id of the list whose members are to be fetched.
	 * @param count - The number of members to fetch. Must be \<= 100.
	 * @param cursor - The cursor to the batch of members to fetch.
	 */
	public static members(id: string, count?: number, cursor?: string): AxiosRequestConfig {
		return {
			method: 'get',
			url: 'https://x.com/i/api/graphql/Bnhcen0kdsMAU1tW7U79qQ/ListMembers',
			params: {
				/* eslint-disable @typescript-eslint/naming-convention */
				variables: JSON.stringify({
					listId: id,
					count: count,
					cursor: cursor,
				}),
				features: JSON.stringify({
					rweb_video_screen_enabled: false,
					profile_label_improvements_pcf_label_in_post_enabled: true,
					responsive_web_profile_redirect_enabled: false,
					rweb_tipjar_consumption_enabled: true,
					verified_phone_label_enabled: true,
					creator_subscriptions_tweet_preview_api_enabled: true,
					responsive_web_graphql_timeline_navigation_enabled: true,
					responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
					premium_content_api_read_enabled: false,
					communities_web_enable_tweet_community_results_fetch: true,
					c9s_tweet_anatomy_moderator_badge_enabled: true,
					responsive_web_grok_analyze_button_fetch_trends_enabled: false,
					responsive_web_grok_analyze_post_followups_enabled: true,
					responsive_web_jetfuel_frame: true,
					responsive_web_grok_share_attachment_enabled: true,
					articles_preview_enabled: true,
					responsive_web_edit_tweet_api_enabled: true,
					graphql_is_translatable_rweb_tweet_is_translatable_enabled: true,
					view_counts_everywhere_api_enabled: true,
					longform_notetweets_consumption_enabled: true,
					responsive_web_twitter_article_tweet_consumption_enabled: true,
					tweet_awards_web_tipping_enabled: false,
					responsive_web_grok_show_grok_translated_post: false,
					responsive_web_grok_analysis_button_from_backend: true,
					creator_subscriptions_quote_tweet_preview_enabled: false,
					freedom_of_speech_not_reach_fetch_enabled: true,
					standardized_nudges_misinfo: true,
					tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled: true,
					longform_notetweets_rich_text_read_enabled: true,
					longform_notetweets_inline_media_enabled: true,
					responsive_web_grok_image_annotation_enabled: true,
					responsive_web_grok_imagine_annotation_enabled: true,
					responsive_web_grok_community_note_auto_translation_is_enabled: false,
					responsive_web_enhance_cards_enabled: false,
				}),
				/* eslint-enable @typescript-eslint/naming-convention */
			},
		};
	}

	/**
	 * @param id - The ID of the list to mute.
	 */
	public static mute(id: string): AxiosRequestConfig {
		return {
			method: 'post',
			headers: { referer: `https://x.com/i/lists/${id}` },
			url: 'https://x.com/i/api/graphql/ZYyanJsskNUcltu9bliMLA/MuteList',
			data: {
				variables: {
					listId: id,
				},
				queryId: 'ZYyanJsskNUcltu9bliMLA',
			},
		};
	}

	/**
	 * @param listId - The ID of the target list.
	 * @param userId - The ID of the user to remove as a member.
	 */
	public static removeMember(listId: string, userId: string): AxiosRequestConfig {
		return {
			method: 'post',
			url: 'https://x.com/i/api/graphql/B5tMzrMYuFHJex_4EXFTSw/ListRemoveMember',
			data: {
				/* eslint-disable @typescript-eslint/naming-convention */

				variables: {
					listId: listId,
					userId: userId,
				},
				features: {
					profile_label_improvements_pcf_label_in_post_enabled: true,
					responsive_web_profile_redirect_enabled: false,
					rweb_tipjar_consumption_enabled: true,
					verified_phone_label_enabled: true,
					responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
					responsive_web_graphql_timeline_navigation_enabled: true,
				},

				/* eslint-enable @typescript-eslint/naming-convention */
			},
		};
	}

	/**
	 * @param id - The id of the list whose tweets are to be fetched.
	 * @param count - The number of tweets to fetch. Must be \<= 100.
	 * @param cursor - The cursor to the batch of tweets to fetch.
	 */
	public static tweets(id: string, count?: number, cursor?: string): AxiosRequestConfig {
		return {
			method: 'get',
			url: 'https://x.com/i/api/graphql/fqNUs_6rqLf89u_2waWuqg/ListLatestTweetsTimeline',
			params: {
				/* eslint-disable @typescript-eslint/naming-convention */
				variables: JSON.stringify({
					listId: id,
					count: count,
					cursor: cursor,
				}),
				features: JSON.stringify({
					rweb_video_screen_enabled: false,
					profile_label_improvements_pcf_label_in_post_enabled: true,
					responsive_web_profile_redirect_enabled: false,
					rweb_tipjar_consumption_enabled: true,
					verified_phone_label_enabled: true,
					creator_subscriptions_tweet_preview_api_enabled: true,
					responsive_web_graphql_timeline_navigation_enabled: true,
					responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
					premium_content_api_read_enabled: false,
					communities_web_enable_tweet_community_results_fetch: true,
					c9s_tweet_anatomy_moderator_badge_enabled: true,
					responsive_web_grok_analyze_button_fetch_trends_enabled: false,
					responsive_web_grok_analyze_post_followups_enabled: true,
					responsive_web_jetfuel_frame: true,
					responsive_web_grok_share_attachment_enabled: true,
					articles_preview_enabled: true,
					responsive_web_edit_tweet_api_enabled: true,
					graphql_is_translatable_rweb_tweet_is_translatable_enabled: true,
					view_counts_everywhere_api_enabled: true,
					longform_notetweets_consumption_enabled: true,
					responsive_web_twitter_article_tweet_consumption_enabled: true,
					tweet_awards_web_tipping_enabled: false,
					responsive_web_grok_show_grok_translated_post: false,
					responsive_web_grok_analysis_button_from_backend: true,
					creator_subscriptions_quote_tweet_preview_enabled: false,
					freedom_of_speech_not_reach_fetch_enabled: true,
					standardized_nudges_misinfo: true,
					tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled: true,
					longform_notetweets_rich_text_read_enabled: true,
					longform_notetweets_inline_media_enabled: true,
					responsive_web_grok_image_annotation_enabled: true,
					responsive_web_grok_imagine_annotation_enabled: true,
					responsive_web_grok_community_note_auto_translation_is_enabled: false,
					responsive_web_enhance_cards_enabled: false,
				}),
				/* eslint-enable @typescript-eslint/naming-convention */
			},
			paramsSerializer: { encode: encodeURIComponent },
		};
	}

	/**
	 * @param id - The ID of the list to unmute.
	 */
	public static unmute(id: string): AxiosRequestConfig {
		return {
			method: 'post',
			headers: { referer: `https://x.com/i/lists/${id}` },
			url: 'https://x.com/i/api/graphql/pMZrHRNsmEkXgbn3tOyr7Q/UnmuteList',
			data: {
				variables: {
					listId: id,
				},
				queryId: 'pMZrHRNsmEkXgbn3tOyr7Q',
			},
		};
	}

	/**
	 * @param id - The ID of the list to update.
	 * @param updates - The updates to apply.
	 */
	public static update(id: string, updates: IListUpdates): AxiosRequestConfig {
		return {
			method: 'post',
			headers: { referer: `https://x.com/i/lists/${id}/info` },
			url: 'https://x.com/i/api/graphql/UzVGAR_brbQw1n3mH_PqRA/UpdateList',
			data: {
				/* eslint-disable @typescript-eslint/naming-convention */

				variables: {
					listId: id,
					...(updates.isPrivate !== undefined ? { isPrivate: updates.isPrivate } : {}),
					...(updates.description !== undefined ? { description: updates.description } : {}),
					...(updates.name !== undefined ? { name: updates.name } : {}),
				},
				features: {
					profile_label_improvements_pcf_label_in_post_enabled: true,
					responsive_web_profile_redirect_enabled: false,
					rweb_tipjar_consumption_enabled: false,
					verified_phone_label_enabled: false,
					responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
					responsive_web_graphql_timeline_navigation_enabled: true,
				},
				queryId: 'UzVGAR_brbQw1n3mH_PqRA',

				/* eslint-enable @typescript-eslint/naming-convention */
			},
		};
	}
}
