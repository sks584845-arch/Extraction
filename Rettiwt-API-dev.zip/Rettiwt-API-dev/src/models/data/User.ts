import { LogActions } from '../../enums/Logging';
import { findByFilter } from '../../helper/JsonUtils';
import { LogService } from '../../services/internal/LogService';
import { IUser } from '../../types/data/User';
import { IUser as IRawUser } from '../../types/raw/base/User';
import { ITimelineUser as IRawTimelineUser } from '../../types/raw/composite/TimelineUser';

/**
 * The details of a single user.
 *
 * @public
 */
export class User implements IUser {
	/** The raw user details. */
	private readonly _raw: IRawUser;

	public createdAt: string;
	public description?: string;
	public followersCount: number;
	public followingsCount: number;
	public fullName: string;
	public id: string;
	public isFollowed?: boolean;
	public isFollowing?: boolean;
	public isVerified: boolean;
	public likeCount: number;
	public location?: string;
	public pinnedTweets: string[];
	public profileBanner?: string;
	public profileImage: string;
	public statusesCount: number;
	public userName: string;

	/**
	 * @param user - The raw user details.
	 */
	public constructor(user: IRawUser) {
		this._raw = { ...user };
		this.id = user.rest_id;
		this.userName = user.core?.screen_name ?? user.legacy.screen_name ?? '';
		this.fullName = user.core?.name ?? user.legacy.name ?? '';
		this.createdAt = new Date(user.core?.created_at ?? user.legacy.created_at ?? 0).toISOString();
		this.description = user.legacy.description.length ? user.legacy.description : undefined;
		this.isFollowed = user.legacy.following;
		this.isFollowing = user.legacy.followed_by;
		this.isVerified = user.is_blue_verified;
		this.likeCount = user.legacy.favourites_count;
		this.followersCount = user.legacy.followers_count;
		this.followingsCount = user.legacy.friends_count;
		this.statusesCount = user.legacy.statuses_count;
		this.location = user.location?.location ?? user.legacy.location ?? undefined;
		this.pinnedTweets = user.legacy.pinned_tweet_ids_str ?? [];
		this.profileBanner = user.legacy.profile_banner_url;
		this.profileImage = user.avatar?.image_url ?? user.legacy.profile_image_url_https ?? '';
	}

	/** The raw user details. */
	public get raw(): IRawUser {
		return { ...this._raw };
	}

	/**
	 * Extracts and deserializes multiple target users from the given raw response data.
	 *
	 * @param response - The raw response data.
	 * @param ids - The ids of the target users.
	 *
	 * @returns The target deserialized users.
	 */
	public static multiple(response: NonNullable<unknown>, ids: string[]): User[] {
		let users: User[] = [];

		// Extracting the matching data
		const extract = findByFilter<IRawUser>(response, '__typename', 'User');

		// Deserializing valid data
		for (const item of extract) {
			if (item.legacy && (item.core?.created_at || item.legacy.created_at)) {
				// Logging
				LogService.log(LogActions.DESERIALIZE, { id: item.rest_id });

				users.push(new User(item));
			} else {
				// Logging
				LogService.log(LogActions.WARNING, {
					action: LogActions.DESERIALIZE,
					message: `User not found, skipping`,
				});
			}
		}

		// Filtering only required user, if required
		if (ids && ids.length) {
			users = users.filter((user) => ids.includes(user.id));
		}

		return users;
	}

	/**
	 * Extracts and deserializes a single target user from the given raw response data.
	 *
	 * @param response - The raw response data.
	 *
	 * @returns The target deserialized user.
	 */
	public static single(response: NonNullable<unknown>): User | undefined {
		const users: User[] = [];

		// Extracting the matching data
		const extract = findByFilter<IRawUser>(response, '__typename', 'User');

		// Deserializing valid data
		for (const item of extract) {
			if (item.legacy && (item.core?.created_at || item.legacy.created_at)) {
				// Logging
				LogService.log(LogActions.DESERIALIZE, { id: item.rest_id });

				users.push(new User(item));
			} else {
				// Logging
				LogService.log(LogActions.WARNING, {
					action: LogActions.DESERIALIZE,
					message: `User not found, skipping`,
				});
			}
		}

		return users.length ? users[0] : undefined;
	}

	/**
	 * Extracts and deserializes the timeline of users from the given raw response data.
	 *
	 * @param response - The raw response data.
	 *
	 * @returns The deserialized timeline of users.
	 */
	public static timeline(response: NonNullable<unknown>): User[] {
		const users: User[] = [];

		// Extracting the matching data
		const extract = findByFilter<IRawTimelineUser>(response, '__typename', 'TimelineUser');

		// Deserializing valid data
		for (const item of extract) {
			if (item.user_results?.result?.legacy) {
				// Logging
				LogService.log(LogActions.DESERIALIZE, { id: item.user_results.result.rest_id });

				users.push(new User(item.user_results.result));
			} else {
				// Logging
				LogService.log(LogActions.WARNING, {
					action: LogActions.DESERIALIZE,
					message: `User not found, skipping`,
				});
			}
		}

		return users;
	}

	/**
	 * @returns A serializable JSON representation of `this` object.
	 */
	public toJSON(): IUser {
		return {
			createdAt: this.createdAt,
			description: this.description,
			followersCount: this.followersCount,
			followingsCount: this.followingsCount,
			fullName: this.fullName,
			id: this.id,
			isFollowed: this.isFollowed,
			isFollowing: this.isFollowing,
			isVerified: this.isVerified,
			likeCount: this.likeCount,
			location: this.location,
			pinnedTweets: this.pinnedTweets,
			profileBanner: this.profileBanner,
			profileImage: this.profileImage,
			statusesCount: this.statusesCount,
			userName: this.userName,
		};
	}
}
