import {
	IChangePasswordArgs,
	IListUpdates,
	INewList,
	INewTweet,
	INewTweetMedia,
	IPostArgs,
	IUploadArgs,
} from '../../types/args/PostArgs';

import { ProfileUpdateOptions } from './ProfileArgs';

/**
 * Options specifying the data that is to be posted.
 *
 * @public
 */
export class PostArgs implements IPostArgs {
	public changePassword?: ChangePasswordArgs;
	public conversationId?: string;
	public id?: string;
	public list?: NewList;
	public listUpdates?: ListUpdates;
	public profileBanner?: string;
	public profileImage?: string;
	public profileOptions?: ProfileUpdateOptions;
	public tweet?: NewTweet;
	public upload?: UploadArgs;
	public userId?: string;
	public username?: string;

	/**
	 * @param resource - The resource to be posted.
	 * @param args - Additional user-defined arguments for posting the resource.
	 */
	public constructor(args: IPostArgs) {
		this.id = args.id;
		this.list = args.list ? new NewList(args.list) : undefined;
		this.tweet = args.tweet ? new NewTweet(args.tweet) : undefined;
		this.upload = args.upload ? new UploadArgs(args.upload) : undefined;
		this.userId = args.userId;
		this.username = PostArgs._validateNonEmptyString(args.username, 'Username');
		this.conversationId = args.conversationId;
		this.profileOptions = args.profileOptions ? new ProfileUpdateOptions(args.profileOptions) : undefined;
		this.profileImage = PostArgs._validateNonEmptyString(args.profileImage, 'Profile image');
		this.profileBanner = PostArgs._validateNonEmptyString(args.profileBanner, 'Profile banner');
		this.changePassword = args.changePassword ? new ChangePasswordArgs(args.changePassword) : undefined;
		this.listUpdates = args.listUpdates ? new ListUpdates(args.listUpdates) : undefined;
	}

	/**
	 * Validates if a data value is a valid string.
	 *
	 * @param value - The data to validate.
	 * @param fieldName - The field name whose value is to be validated.
	 *
	 * @returns The validated, parsed string. If data was `undefined`, returns `undefined`.
	 */
	private static _validateNonEmptyString(value: unknown, fieldName: string): string | undefined {
		if (value === undefined) {
			return undefined;
		}

		if (typeof value !== 'string') {
			throw new Error(`${fieldName} must be a string`);
		}

		if (value.trim().length === 0) {
			throw new Error(`${fieldName} cannot be empty`);
		}

		return value;
	}
}

/**
 * Configuration for the list to be created.
 *
 * @public
 */
export class NewList implements INewList {
	public description?: string;
	public isPrivate: boolean;
	public name: string;

	/**
	 * @param newList - The args specifying the list to be created.
	 */
	public constructor(newList: INewList) {
		this.name = newList.name;
		this.description = newList.description;
		this.isPrivate = newList.isPrivate ?? false;
	}
}

/**
 * Configuration for the updates to apply to an existing list.
 *
 * @public
 */
export class ListUpdates implements IListUpdates {
	public description?: string;
	public isPrivate?: boolean;
	public name?: string;

	/**
	 * @param updates - The updates to apply to the target list.
	 */
	public constructor(updates: IListUpdates) {
		this.name = updates.name;
		this.description = updates.description;
		this.isPrivate = updates.isPrivate;
	}
}

/**
 * Configuration for the new tweet to be posted.
 *
 * @public
 */
export class NewTweet implements INewTweet {
	public media?: NewTweetMedia[];
	public quote?: string;
	public replyTo?: string;
	public scheduleFor?: Date;
	public text: string;

	/**
	 * @param newTweet - The args specifying the new tweet to be posted.
	 */
	public constructor(newTweet: INewTweet) {
		this.media = newTweet.media;
		this.quote = newTweet.quote;
		this.replyTo = newTweet.replyTo;
		this.scheduleFor = newTweet.scheduleFor;
		this.text = newTweet.text ?? '';
	}
}

/**
 * Configuration for the media to be uploaded.
 *
 * @public
 */
export class NewTweetMedia implements INewTweetMedia {
	public id: string;
	public tags?: string[];

	/**
	 * @param newTweetMedia - The args specifying the new media to be posted along with the tweet.
	 */
	public constructor(newTweetMedia: INewTweetMedia) {
		this.id = newTweetMedia.id;
		this.tags = newTweetMedia.tags;
	}
}

/**
 * Options specifying the media file to be uploaded.
 *
 * @public
 */
export class UploadArgs implements IUploadArgs {
	public id?: string;
	public media?: string | ArrayBuffer;
	public size?: number;

	/**
	 * @param step - The upload step.
	 * @param args - The upload arguments for uploading the media file.
	 */
	public constructor(args: IUploadArgs) {
		this.size = args.size;
		this.media = args.media;
		this.id = args.id;
	}
}

/**
 * The args for changing authenticated user's password.
 *
 * @public
 */
export class ChangePasswordArgs implements IChangePasswordArgs {
	public currentPassword: string;
	public newPassword: string;

	public constructor(args: IChangePasswordArgs) {
		if (!args.currentPassword || args.currentPassword.trim().length === 0) {
			throw new Error('Current password cannot be empty');
		}
		if (!args.newPassword || args.newPassword.trim().length === 0) {
			throw new Error('New password cannot be empty');
		}
		if (args.newPassword.length < 8) {
			throw new Error('New password must be at least 8 characters long');
		}

		this.currentPassword = args.currentPassword;
		this.newPassword = args.newPassword;
	}
}
