module github.com/MontFerret/ferret/v2

go 1.25.0

require (
	github.com/antlr4-go/antlr/v4 v4.13.1
	github.com/gobwas/glob v0.2.3
	github.com/goccy/go-json v0.10.6
	github.com/google/go-cmp v0.7.0
	github.com/jarcoal/httpmock v1.4.2
	github.com/rs/zerolog v1.35.1
	github.com/smartystreets/goconvey v1.8.1
	github.com/vmihailenco/msgpack/v5 v5.4.1
)

require (
	github.com/gopherjs/gopherjs v1.17.2 // indirect
	github.com/jtolds/gls v4.20.0+incompatible // indirect
	github.com/mattn/go-colorable v0.1.14 // indirect
	github.com/mattn/go-isatty v0.0.22 // indirect
	github.com/smarty/assertions v1.16.0 // indirect
	github.com/stretchr/testify v1.11.1 // indirect
	github.com/vmihailenco/tagparser/v2 v2.0.0 // indirect
	golang.org/x/exp v0.0.0-20260410095643-746e56fc9e2f // indirect
	golang.org/x/sys v0.45.0 // indirect
)
