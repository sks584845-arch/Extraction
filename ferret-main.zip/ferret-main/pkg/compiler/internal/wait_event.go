package internal

import (
	"github.com/antlr4-go/antlr/v4"

	"github.com/MontFerret/ferret/v2/pkg/bytecode"
	"github.com/MontFerret/ferret/v2/pkg/compiler/internal/core"
	parserd "github.com/MontFerret/ferret/v2/pkg/parser/diagnostics"
	"github.com/MontFerret/ferret/v2/pkg/parser/fql"
	"github.com/MontFerret/ferret/v2/pkg/source"
)

type waitEventCompileState struct {
	span       source.Span
	srcReg     bytecode.Operand
	eventReg   bytecode.Operand
	optsReg    bytecode.Operand
	timeoutReg bytecode.Operand
}

func (c *WaitCompiler) compileEvent(ctx fql.IWaitForEventExpressionContext) bytecode.Operand {
	if waitForEventTriggerClause(ctx) != nil {
		return c.compileEventWithTriggerCleanup(ctx)
	}

	state, ok := c.buildWaitEventState(ctx)
	if !ok {
		return bytecode.NoopOperand
	}

	streamReg := c.ctx.Function.Registers.Allocate()
	resultReg := c.ctx.Function.Registers.Allocate()

	c.ctx.Program.Emitter.EmitLoadNone(resultReg)
	c.emitWaitEventStreamSetup(state, streamReg)
	c.compileWaitEventTrigger(ctx)

	start := c.ctx.Program.Emitter.NewLabel()
	end := c.ctx.Program.Emitter.NewLabel()

	c.ctx.Program.Emitter.MarkLabel(start)
	c.emitWaitEventIteration(ctx, state, streamReg, resultReg, bytecode.NoopOperand, start, end)

	c.ctx.Program.Emitter.MarkLabel(end)
	c.emitWaitEventCleanup(state, streamReg)

	return resultReg
}

func (c *WaitCompiler) compileEventWithTimeoutRecovery(
	ctx fql.IWaitForEventExpressionContext,
	timeoutLabel, endLabel core.Label,
) bytecode.Operand {
	if waitForEventTriggerClause(ctx) != nil {
		return c.compileEventWithTriggerTimeoutCleanup(ctx, timeoutLabel, endLabel)
	}

	streamReg := c.ctx.Function.Registers.Allocate()
	resultReg := c.ctx.Function.Registers.Allocate()
	timeoutStateReg := c.ctx.Function.Registers.Allocate()

	c.ctx.Program.Emitter.EmitLoadNone(resultReg)
	c.ctx.Program.Emitter.EmitBoolean(timeoutStateReg, false)

	state, ok := c.buildWaitEventState(ctx)
	if !ok {
		return bytecode.NoopOperand
	}

	c.emitWaitEventStreamSetup(state, streamReg)
	c.compileWaitEventTrigger(ctx)

	start := c.ctx.Program.Emitter.NewLabel()
	iterationDone := c.ctx.Program.Emitter.NewLabel()
	cleanup := c.ctx.Program.Emitter.NewLabel()

	c.ctx.Program.Emitter.MarkLabel(start)
	c.emitWaitEventIteration(ctx, state, streamReg, resultReg, timeoutStateReg, start, iterationDone)

	c.ctx.Program.Emitter.EmitJump(cleanup)
	c.ctx.Program.Emitter.MarkLabel(iterationDone)
	c.ctx.Program.Emitter.EmitJump(cleanup)

	c.ctx.Program.Emitter.MarkLabel(cleanup)
	c.emitWaitEventCleanup(state, streamReg)

	c.ctx.Program.Emitter.EmitJumpIfTrue(timeoutStateReg, timeoutLabel)
	c.ctx.Program.Emitter.EmitJump(endLabel)

	return resultReg
}

func (c *WaitCompiler) compileEventWithTriggerCleanup(ctx fql.IWaitForEventExpressionContext) bytecode.Operand {
	streamReg := c.ctx.Function.Registers.Allocate()
	resultReg := c.ctx.Function.Registers.Allocate()
	streamReadyReg := c.ctx.Function.Registers.Allocate()

	c.ctx.Program.Emitter.EmitLoadNone(resultReg)
	c.ctx.Program.Emitter.EmitBoolean(streamReadyReg, false)

	startCatch := c.ctx.Program.Emitter.Size()
	state, ok := c.buildWaitEventState(ctx)
	if !ok {
		return bytecode.NoopOperand
	}

	c.emitWaitEventStreamSetupWithReady(state, streamReg, streamReadyReg)
	c.compileWaitEventTrigger(ctx)

	start := c.ctx.Program.Emitter.NewLabel()
	iterationDone := c.ctx.Program.Emitter.NewLabel()
	exit := c.ctx.Program.Emitter.NewLabel("waitfor", "event", "trigger", "exit")

	c.ctx.Program.Emitter.MarkLabel(start)
	c.emitWaitEventIteration(ctx, state, streamReg, resultReg, bytecode.NoopOperand, start, iterationDone)

	c.ctx.Program.Emitter.MarkLabel(iterationDone)
	c.emitWaitEventCleanupIfReady(state, streamReg, streamReadyReg)
	c.ctx.Program.Emitter.EmitJump(exit)

	endCatchExclusive := c.ctx.Program.Emitter.Size()
	errorHandlerPC := c.ctx.Program.Emitter.Size()
	c.emitWaitEventCleanupIfReady(state, streamReg, streamReadyReg)
	c.ctx.Program.Emitter.Emit(bytecode.OpRethrow)

	c.ctx.Program.Emitter.MarkLabel(exit)
	c.ctx.Program.Emitter.EmitAB(bytecode.OpMove, resultReg, resultReg)

	c.ctx.Program.CatchTable.Push(startCatch, endCatchExclusive-1, errorHandlerPC)

	return resultReg
}

func (c *WaitCompiler) compileEventWithTriggerTimeoutCleanup(
	ctx fql.IWaitForEventExpressionContext,
	timeoutLabel, endLabel core.Label,
) bytecode.Operand {
	streamReg := c.ctx.Function.Registers.Allocate()
	resultReg := c.ctx.Function.Registers.Allocate()
	timeoutStateReg := c.ctx.Function.Registers.Allocate()
	streamReadyReg := c.ctx.Function.Registers.Allocate()

	c.ctx.Program.Emitter.EmitLoadNone(resultReg)
	c.ctx.Program.Emitter.EmitBoolean(timeoutStateReg, false)
	c.ctx.Program.Emitter.EmitBoolean(streamReadyReg, false)

	startCatch := c.ctx.Program.Emitter.Size()
	state, ok := c.buildWaitEventState(ctx)
	if !ok {
		return bytecode.NoopOperand
	}

	c.emitWaitEventStreamSetupWithReady(state, streamReg, streamReadyReg)
	c.compileWaitEventTrigger(ctx)

	start := c.ctx.Program.Emitter.NewLabel()
	iterationDone := c.ctx.Program.Emitter.NewLabel()
	cleanup := c.ctx.Program.Emitter.NewLabel()

	c.ctx.Program.Emitter.MarkLabel(start)
	c.emitWaitEventIteration(ctx, state, streamReg, resultReg, timeoutStateReg, start, iterationDone)

	c.ctx.Program.Emitter.EmitJump(cleanup)
	c.ctx.Program.Emitter.MarkLabel(iterationDone)
	c.ctx.Program.Emitter.EmitJump(cleanup)

	c.ctx.Program.Emitter.MarkLabel(cleanup)
	c.emitWaitEventCleanupIfReady(state, streamReg, streamReadyReg)

	c.ctx.Program.Emitter.EmitJumpIfTrue(timeoutStateReg, timeoutLabel)
	c.ctx.Program.Emitter.EmitJump(endLabel)

	endCatchExclusive := c.ctx.Program.Emitter.Size()
	errorHandlerPC := c.ctx.Program.Emitter.Size()
	c.emitWaitEventCleanupIfReady(state, streamReg, streamReadyReg)
	c.ctx.Program.Emitter.Emit(bytecode.OpRethrow)

	c.ctx.Program.CatchTable.Push(startCatch, endCatchExclusive-1, errorHandlerPC)

	return resultReg
}

func (c *WaitCompiler) buildWaitEventState(ctx fql.IWaitForEventExpressionContext) (waitEventCompileState, bool) {
	state := waitEventCompileState{
		span:     waitForSpan(ctx.WaitForEventSource(), ctx),
		srcReg:   c.CompileWaitForEventSource(ctx.WaitForEventSource()),
		eventReg: c.CompileWaitForEventName(ctx.WaitForEventName()),
	}

	if opts := ctx.OptionsClause(); opts != nil {
		state.optsReg = c.CompileOptionsClause(opts)
	}

	if timeout := waitForEventTimeoutClause(ctx); timeout != nil {
		state.timeoutReg = c.recovery.CompileDurationExpression(timeout.Expression())
		if state.timeoutReg == bytecode.NoopOperand {
			return waitEventCompileState{}, false
		}
	}

	return state, true
}

func (c *WaitCompiler) emitWaitEventStreamSetup(state waitEventCompileState, streamReg bytecode.Operand) {
	c.emitWaitEventStreamSetupWithReady(state, streamReg, bytecode.NoopOperand)
}

func (c *WaitCompiler) emitWaitEventStreamSetupWithReady(state waitEventCompileState, streamReg, streamReadyReg bytecode.Operand) {
	c.ctx.Program.Emitter.WithSpan(state.span, func() {
		c.ctx.Program.Emitter.EmitMove(streamReg, state.srcReg)
		c.ctx.Program.Emitter.EmitABC(bytecode.OpStream, streamReg, state.eventReg, state.optsReg)
		if streamReadyReg != bytecode.NoopOperand {
			c.ctx.Program.Emitter.EmitBoolean(streamReadyReg, true)
		}
		c.ctx.Program.Emitter.EmitABC(bytecode.OpStreamIter, streamReg, streamReg, state.timeoutReg)
	})
}

func (c *WaitCompiler) compileWaitEventTrigger(ctx fql.IWaitForEventExpressionContext) {
	if ctx == nil {
		return
	}

	trigger := waitForEventTriggerClause(ctx)
	if trigger == nil {
		return
	}

	c.compileWaitForTriggerClause(trigger)
}

func (c *WaitCompiler) compileWaitForTriggerClause(ctx fql.IWaitForTriggerClauseContext) {
	if ctx == nil {
		return
	}

	c.ctx.Function.Symbols.EnterScope()
	defer c.ctx.Function.Symbols.ExitScope()

	if c.ctx.Program.Semantics != nil {
		c.ctx.Program.Semantics.EnterScope(parserd.SpanFromRuleContext(ctx.(antlr.ParserRuleContext)))
		defer c.ctx.Program.Semantics.ExitScope()
	}

	if inline := ctx.WaitForTriggerInlineStatement(); inline != nil {
		c.compileWaitForTriggerInlineStatement(inline)
		return
	}

	for _, stmt := range ctx.AllWaitForTriggerStatement() {
		c.compileWaitForTriggerStatement(stmt)
	}
}

func (c *WaitCompiler) compileWaitForTriggerStatement(ctx fql.IWaitForTriggerStatementContext) {
	if ctx == nil {
		return
	}

	if vd := ctx.VariableDeclaration(); vd != nil {
		c.bindings.CompileVariableDeclaration(vd)
	} else if as := ctx.AssignmentStatement(); as != nil {
		c.bindings.CompileAssignmentStatement(as)
	} else if ds := ctx.DeleteStatement(); ds != nil {
		c.bindings.CompileDeleteStatement(ds)
	} else if fce := ctx.FunctionCallExpression(); fce != nil {
		c.exprs.CompileFunctionCallExpression(fce)
	} else if wfe := ctx.WaitForExpression(); wfe != nil {
		c.Compile(wfe)
	} else if de := ctx.DispatchExpression(); de != nil {
		c.dispatch.Compile(de)
	}
}

func (c *WaitCompiler) compileWaitForTriggerInlineStatement(ctx fql.IWaitForTriggerInlineStatementContext) {
	if ctx == nil {
		return
	}

	if vd := ctx.VariableDeclaration(); vd != nil {
		c.bindings.CompileVariableDeclaration(vd)
	} else if as := ctx.AssignmentStatement(); as != nil {
		c.bindings.CompileAssignmentStatement(as)
	} else if ds := ctx.DeleteStatement(); ds != nil {
		c.bindings.CompileDeleteStatement(ds)
	} else if fce := ctx.FunctionCallNoRecoveryExpression(); fce != nil {
		c.exprs.CompileFunctionCallNoRecoveryExpression(fce)
	} else if dispatch := ctx.WaitForTriggerInlineDispatchStatement(); dispatch != nil {
		c.compileWaitForTriggerInlineDispatchStatement(dispatch)
	}
}

func (c *WaitCompiler) compileWaitForTriggerInlineDispatchStatement(ctx fql.IWaitForTriggerInlineDispatchStatementContext) {
	if ctx == nil {
		return
	}

	c.dispatch.compileCore(
		ctx.DispatchTarget(),
		ctx.DispatchEventName(),
		ctx.DispatchWithClause(),
		ctx.DispatchOptionsClause(),
		c.dispatch.dispatchSpan(ctx),
	)
}

func (c *WaitCompiler) emitWaitEventIteration(
	ctx fql.IWaitForEventExpressionContext,
	state waitEventCompileState,
	streamReg, resultReg, timeoutStateReg bytecode.Operand,
	restartLabel, doneLabel core.Label,
) {
	c.ctx.Program.Emitter.WithSpan(state.span, func() {
		if timeoutStateReg != bytecode.NoopOperand {
			c.ctx.Program.Emitter.EmitIterNextTimeout(streamReg, timeoutStateReg, doneLabel)
			return
		}

		c.ctx.Program.Emitter.EmitIterNext(streamReg, doneLabel)
	})

	filters := ctx.AllEventFilterClause()
	if len(filters) == 0 {
		c.ctx.Program.Emitter.WithSpan(state.span, func() {
			c.ctx.Program.Emitter.EmitIterValue(resultReg, streamReg)
		})
		return
	}

	eventValReg, _ := c.ctx.Function.Symbols.DeclareLocal(core.PseudoVariable, core.TypeUnknown)

	c.ctx.Program.Emitter.WithSpan(state.span, func() {
		c.ctx.Program.Emitter.EmitIterValue(eventValReg, streamReg)
	})

	for _, filter := range filters {
		cond := c.exprs.CompileWithImplicitCurrent(filter.Expression())
		c.ctx.Program.Emitter.EmitJumpIfFalse(cond, restartLabel)
	}

	c.ctx.Program.Emitter.WithSpan(state.span, func() {
		c.ctx.Program.Emitter.EmitMove(resultReg, eventValReg)
	})
}

func (c *WaitCompiler) emitWaitEventCleanup(state waitEventCompileState, streamReg bytecode.Operand) {
	c.ctx.Program.Emitter.WithSpan(state.span, func() {
		c.ctx.Program.Emitter.EmitA(bytecode.OpClose, streamReg)
	})
}

func (c *WaitCompiler) emitWaitEventCleanupIfReady(state waitEventCompileState, streamReg, streamReadyReg bytecode.Operand) {
	if streamReadyReg == bytecode.NoopOperand {
		c.emitWaitEventCleanup(state, streamReg)

		return
	}

	skip := c.ctx.Program.Emitter.NewLabel("waitfor", "event", "cleanup", "skip")
	c.ctx.Program.Emitter.EmitJumpIfFalse(streamReadyReg, skip)
	c.emitWaitEventCleanup(state, streamReg)
	c.ctx.Program.Emitter.EmitBoolean(streamReadyReg, false)
	c.ctx.Program.Emitter.MarkLabel(skip)
}

// CompileWaitForEventName processes the event name expression in a WAITFOR statement.
func (c *WaitCompiler) CompileWaitForEventName(ctx fql.IWaitForEventNameContext) bytecode.Operand {
	sl := ctx.StringLiteral()
	v := ctx.Variable()
	p := ctx.Param()
	me := ctx.MemberExpression()
	fce := ctx.FunctionCall()

	return compileFirstOperand(
		newOperandBranch(sl != nil, func() bytecode.Operand { return c.literals.CompileStringLiteral(sl) }),
		newOperandBranch(v != nil, func() bytecode.Operand { return c.exprs.CompileVariable(v) }),
		newOperandBranch(p != nil, func() bytecode.Operand { return c.exprs.CompileParam(p) }),
		newOperandBranch(me != nil, func() bytecode.Operand { return c.exprs.CompileMemberExpression(me) }),
		newOperandBranch(fce != nil, func() bytecode.Operand { return c.exprs.CompileFunctionCall(fce, false) }),
	)
}

// CompileWaitForEventSource processes the event source expression in a WAITFOR statement.
func (c *WaitCompiler) CompileWaitForEventSource(ctx fql.IWaitForEventSourceContext) bytecode.Operand {
	v := ctx.Variable()
	me := ctx.MemberExpression()
	fce := ctx.FunctionCallExpression()

	return compileFirstOperand(
		newOperandBranch(v != nil, func() bytecode.Operand { return c.exprs.CompileVariable(v) }),
		newOperandBranch(me != nil, func() bytecode.Operand { return c.exprs.CompileMemberExpression(me) }),
		newOperandBranch(fce != nil, func() bytecode.Operand { return c.exprs.CompileFunctionCallExpression(fce) }),
	)
}

// CompileOptionsClause processes the options clause in a WAITFOR statement.
func (c *WaitCompiler) CompileOptionsClause(ctx fql.IOptionsClauseContext) bytecode.Operand {
	if ol := ctx.ObjectLiteral(); ol != nil {
		return c.literals.CompileObjectLiteral(ol)
	}

	return bytecode.NoopOperand
}
